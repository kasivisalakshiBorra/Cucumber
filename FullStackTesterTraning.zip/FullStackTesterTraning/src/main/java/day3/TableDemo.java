package day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TableDemo {

	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating tōo google
		wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		List<WebElement> weColData=wd.findElements(By.xpath("//table[@id='customers']//tr//td"));
		for(int i=0;i<weColData.size();i++) {
			System.out.println(weColData.get(i).getText());
			
			
		}
	
		
		wd.close();
		
	}
	
}