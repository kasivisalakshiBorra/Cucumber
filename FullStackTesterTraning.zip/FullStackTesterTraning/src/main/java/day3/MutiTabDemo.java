package day3;


import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MutiTabDemo {

	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		wd.findElement(By.tagName("body")).sendKeys(Keys.CONTROL + "t");
		Set<String> tabs=wd.getWindowHandles();
		for(String eachTab:tabs) {
			System.out.println(eachTab);
			wd.switchTo().window(eachTab);
		}
		wd.get("https://www.google.com/");
		
		wd.close();
		
	}

}
