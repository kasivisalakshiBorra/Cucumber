package day4;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutor {
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.google.com/");
		wd.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
		Thread.sleep(5000);
		JavascriptExecutor executor = (JavascriptExecutor)wd;
		executor.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		
		WebElement element = wd.findElement(By.partialLinkText("Selenium in diet: MedlinePlus Medical Encyclopedia"));
		executor.executeScript("arguments[0].click();", element);
		wd.close();
	}
}

//.executeScript("document.getElementById('firstName'). value='testuser'");
//.executeScript("arguments[0].value='enter the value here';", element);