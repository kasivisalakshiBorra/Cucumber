package day1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seleniumlauch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			
			System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
			//firefox-webdriver.gecko.driver
			//IE-IE
			WebDriver wd=new ChromeDriver(); 
			wd.get("https://www.google.com/");
			wd.manage().window().maximize();
			Thread.sleep(5000);
			// Extracting Navigated URL
			System.out.println("URL:" + wd.getCurrentUrl());
			// Extracting Title
			System.out.println("TITLE:" + wd.getTitle());
			/*
			wd.navigate().to("https://in.search.yahoo.com/?fr2=inr");
			Thread.sleep(5000);
			//back
			
			wd.navigate().back();
			Thread.sleep(5000);
			//forward
			wd.navigate().forward();
			Thread.sleep(5000);
			//refresh
			wd.navigate().refresh();
			
			*/
			//.dr
			
			
			// Closing Chrome
				wd.close();
		
			
			
			
			
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
